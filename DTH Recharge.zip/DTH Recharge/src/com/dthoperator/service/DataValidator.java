package com.dthoperator.service;

import java.util.regex.Pattern;

public class DataValidator {
	
	public static boolean validateOperator(String operator){
		if(operator.equalsIgnoreCase("AIRTEL")||operator.equalsIgnoreCase("DISHTV")||operator.equalsIgnoreCase("RELIANCE"))
		{
			return true;
		}
		else
		{
			System.out.println("Select from Airtel / DishTV / Reliance");
			return false;
		}	
	}
	
	public static boolean validateConsumerNo(String no)
	{
		String pattern = "[0-9]+{10}";
		if(Pattern.matches(pattern, no))
		{
			return true;
		}
		else
		{
			System.out.println("Enter a valid user number");
			return false;
		}
	}
	
	public static boolean validatePlan(String plan)
	{
		if(plan.equalsIgnoreCase("MONTHLY")||plan.equalsIgnoreCase("YEARLY")||plan.equalsIgnoreCase("QUARTERLY"))
		{
			return true;
		}
		else
		{
			System.out.println("Choose a proper plan");
			return false;
		}
	}
	
	public static boolean validateAmount(String amount){
		String payment = "[0-9]*";
		if(Pattern.matches(payment, amount))
		{
			return true;
		}
		else
		{
			System.out.println("Enter proper amount");
			return false;
		}
		
}
	

}
