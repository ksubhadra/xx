package com.dthoperator.junit;

@interface Before {

}
