package com.dthoperator.junit;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Test;

import com.dthoperator.bean.RechargeDetails;
import com.dthoperator.exception.RechargeExceptions;
import com.dthoperator.service.CollectionHelper;

public class RechargeCollectionTest {

	@Before
	public void setUp() throws Exception {
	}
	CollectionHelper r = new CollectionHelper();
	
	@After
	public void tearDown() throws RechargeExceptions {
	}

	@SuppressWarnings("deprecation")
	public void testAddItems() throws RechargeExceptions {
		
		r.addRecharge(new RechargeDetails("Airtel", "1234567890", "Monthly", 123, 3698));
	}
	
	@Test
	public void testToAddNewDetails() throws RechargeExceptions
	{
		r.addRecharge(new RechargeDetails("TATASky", "987456321", "Monthly", 5620, 1478));
	}
	
	@Test
	public void test()
	{
		r = null;
		System.out.println(r);
	}
	@Test
	public void testcase()
	{
		CollectionHelper r = new CollectionHelper();
		CollectionHelper r1 = new CollectionHelper();
	}

}
